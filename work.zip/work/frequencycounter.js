function sameFrequency(num1 ,num2){
    // good luck. Add any arguments you deem necessary.
    if(num1.length !== num2.length) return false;
    let countnum1 = {};
    let countnum2 = {};
     
    for(let i1 in num1)
    {
        countnum1[num1[i1]] = (countnum1[num1[i1]]||0)+1;
        console.log(countnum1)

    }
    for(let i2 in num2)
    {
        countnum2[num2[i2]] = (countnum2[num2[i2]]||0)+1;
    }
    
    for(let key in countnum1){
      if(countnum1[key] !== countnum2[key]) return false;
    }
    
    return true;
    
      
    
    
}

console.log(sameFrequency("182","281"))
console.log(sameFrequency("34","14"))

console.log(sameFrequency("3589578","5879385"))

console.log(sameFrequency("22","222"))

