function validAnagram(str1 , str2){
   let countstr1={};
    let countstr2={};
    
    if(str1.length !== str2.length)return false;
    // add whatever parameters you deem necessary - good luck!
    else{
    
    for(let val1 of str1)
    {

        countstr1[val1]= (countstr1[val1]||0)+1;
    }
    for(let val2 of str2){
        
        countstr2[val2] = (countstr2[val2]||0)+1;
    }
    for(let key in countstr1)
    {
        if(countstr1[key] !== countstr2[key]) return false;
    }
    return true;
  }
}
 console.log(validAnagram('india','inia'))