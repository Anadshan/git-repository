function areThereDuplicates() {
    // good luck. (supply any arguments you deem necessary.)
    console.log(arguments)
    let num = arguments;

    let countnum={};
    for(let val of num){
        countnum[val] = (countnum[val]||0)+1;
    }
    for(let key in countnum){

        if(countnum[key] > 1) return true;
    }
    return false;
    
    
  }

  console.log( areThereDuplicates(1,2,2))