function minSubArrayLen(arr,num){
     
    let i=0;
    let j=0;
    let s=0;
    let ml = Number.MAX_SAFE_INTEGER;
    if (i===j) {
        s=arr[i];
    }
    while (i<arr.length && j<arr.length){
        if (s<num) {
            j+=1;
            s+=arr[j];
        } else {
            ml = Math.min(ml, j-i+1);
            s-=arr[i];
            i+=1;
        }
    }
    if (i===0) return 0
    return ml;
    
    
    
       
   
}