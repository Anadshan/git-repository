<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<input type="text" name="addtask" id="task" required minlength="8">
<button type="submit" class="btn btn-primary" id="addTaskButton">Add Tasks</button>
</form>
<h2>Pending Task</h2>
<div id="pendingTasks">

    <?php $__currentLoopData = $task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php if($value->status==0): ?>
        <div id="<?php echo e($value->id); ?>">
            <div class="markascomplete" ><input type="checkbox" name="pcheckbox" id="checkbox"></div>
            <div class="pendingtask" name="task"><?php echo e($value->addtask); ?></div>
            <button type="submit" class="btn btn-primary" id="<?php echo e($value->id); ?>">Delete</button>
        </div>
    <?php endif; ?>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<h2>Completed Task</h2>
<div id="completedTasks">
    <?php $__currentLoopData = $task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php if($value->status==1): ?>
    <div id="<?php echo e($value->id); ?>">
        <div class="markasincomplete" ><input type="checkbox" name="checkbox" id="checkbox"></div>
        <div class="completedtask"><?php echo e($value->addtask); ?></div>
        <button type="submit" class="btn btn-primary" id="<?php echo e($value->id); ?>">Delete</button>
    </div>
    <?php endif; ?>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<script>
$(document).ready(function () {

    const Ptemp = (id, task) => {
        return `<div id="${id}">
            <div class="markascomplete" ><input type="checkbox" name="pcheckbox" id="checkbox"></div>
            <div class="pendingtask" name="task">${task}</div>
            <button type="submit" class="btn btn-primary" id="${id}">Delete</button>
        </div>

        `
    }

    // function to add data on add task button click
    $('#addTaskButton').click(function(){
        const task =$('#task').val();
        
       
        
        $.ajax({
            type: "POST",
            url: "/task",
            data: {
                _token: "<?php echo e(csrf_token()); ?>",
                task: task
            },
            success: function (response) {
                //alert('data submitted successfully');
               const id= JSON.parse(response).taskObject.id;
               const taskBack = JSON.parse(response).taskObject.addtask
               $('#pendingTasks').append(Ptemp( id ,taskBack));
            }
        });

    });


    // function to change status of task from pending to complete

      //  $('#pendingTask > div >div[type="checkbox"]').click(function(){
         //   const id= $(this)
//        })
        








    // function to change status of task from complete to pending








    // function to delete task


});
    


</script><?php /**PATH C:\Users\samma\Desktop\work\todoapp\todoapp\resources\views/todo.blade.php ENDPATH**/ ?>