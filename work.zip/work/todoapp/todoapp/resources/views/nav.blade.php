    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="{{asset('assets/css/register.css')}}">
        <link rel="stylesheet" href="{{asset('assets/css/nav.css')}}">
       
            <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
        


         <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
      
        
    </head>
    <body>
        <div>
            @auth
                
            <h2>Todo App</h2>
        <div class="loginregister   ">
            <span>{{Auth::user()->name}}</span>
            <a href="logout">logout</a>
            @endauth
            @guest
            <h2>Todo App</h2>
            <div class="loginregister   ">
                <a href="login">Login</a>
                <a href="register">Register</a>  
            @endguest
        

        </div>
     </div>
        
    </body>
    </html>