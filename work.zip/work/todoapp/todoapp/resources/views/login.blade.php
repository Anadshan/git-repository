<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{asset('assets/css/register.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/nav.css')}}">
   <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Login</title>
    
</head>
<body>
  <div class="header">  @include('nav') </div>
<form action="login" method="POST">
    @csrf
 <div class="form-group">
     <label for="inputemail" class="col-sm-2 control-label">Email:</label>
     <div class="col-sm-10">
         <input type="email" name="email" id="inputemail" class="form-control" value="" required="required">
     </div>
 </div>
 <div class="form-group">
     <label for="inputpassword" class="col-sm-2 control-label">Password:</label>
     <div class="col-sm-10">
         <input type="password" name="password" id="inputpassword" class="form-control" required="required">
     </div>
 </div>
 <div class="form-group">
    <div class="col-sm-10 col-sm-offset-2">
        <button type="submit" class="btn btn-primary" id="button">Login</button>
    </div>
</div>