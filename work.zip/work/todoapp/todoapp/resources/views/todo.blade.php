@include('nav')
<input type="text" name="addtask" id="task" required minlength="8">
<button type="submit" class="btn btn-primary" id="addTaskButton">Add Tasks</button>
</form>
<h2>Pending Task</h2>
<div id="pendingTasks">

    @foreach ($task as $key => $value )

    @if ($value->status==0)
        <div id="{{$value->id}}">
            <div class="markascomplete" ><input type="checkbox" name="pcheckbox" id="checkbox"></div>
            <div class="pendingtask" name="task">{{$value->addtask}}</div>
            <button type="submit" class="btn btn-primary" id="{{$value->id}}">Delete</button>
        </div>
    @endif
        
    @endforeach
</div>


<h2>Completed Task</h2>
<div id="completedTasks">
    @foreach ($task as $key => $value )

    @if ($value->status==1)
    <div id="{{$value->id}}">
        <div class="markasincomplete" ><input type="checkbox" name="checkbox" id="checkbox"></div>
        <div class="completedtask">{{$value->addtask}}</div>
        <button type="submit" class="btn btn-primary" id="{{$value->id}}">Delete</button>
    </div>
    @endif
        
    @endforeach
</div>
<script>
$(document).ready(function () {

    const Ptemp = (id, task) => {
        return `<div id="${id}">
            <div class="markascomplete" ><input type="checkbox" name="pcheckbox" id="checkbox"></div>
            <div class="pendingtask" name="task">${task}</div>
            <button type="submit" class="btn btn-primary" id="${id}">Delete</button>
        </div>

        `
    }

    // function to add data on add task button click
    $('#addTaskButton').click(function(){
        const task =$('#task').val();
        
       
        
        $.ajax({
            type: "POST",
            url: "/task",
            data: {
                _token: "{{csrf_token()}}",
                task: task
            },
            success: function (response) {
                //alert('data submitted successfully');
               const id= JSON.parse(response).taskObject.id;
               const taskBack = JSON.parse(response).taskObject.addtask
               $('#pendingTasks').append(Ptemp( id ,taskBack));
            }
        });

    });


    // function to change status of task from pending to complete

      //  $('#pendingTask > div >div[type="checkbox"]').click(function(){
         //   const id= $(this)
//        })
        








    // function to change status of task from complete to pending








    // function to delete task


});
    


</script>