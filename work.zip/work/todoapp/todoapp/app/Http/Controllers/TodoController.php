<!-- <?php

// namespace App\Http\Controllers;

// use Illuminate\Http\Request;
// use App\User;
// use App\Task;
// class TodoController extends Controller
// {
//     public function index(Request $request){
//         $tasks = User::find($request->user()->id)->task;
//       $tasks->  $pendingTasks = array();
//         $completedTasks = array();

//         foreach ($tasks as $key => $task) {
//             if($task->status)
//                 array_push($completedTasks, $task);
//             else
//                 array_push($pendingTasks, $task);

//         }
//         return view('todo')->with('pendingTasks', $pendingTasks)->with('completedTasks',$completedTasks);
//     }
// }
// } -->
