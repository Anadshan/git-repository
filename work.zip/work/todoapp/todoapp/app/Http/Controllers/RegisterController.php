<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\Hash;

class RegisterController extends Controller
{
    public function register(Request $request)
    {
        $register= new User;
        $register->name = $request->name;
        $register->email = $request->email;
        $register->password =Hash::make($request->password);
        $register->save();
        return redirect('login');
    }
}
