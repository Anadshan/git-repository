<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Task;
use App\Http\Controllers\TodoController;


class TaskController extends Controller
{
    public function index(Request $request)
    {
        // $pTask = [];
        // $cTask = [];

        $task= Task::all()->where('user_id',$request->user()->id); // Todo: fetch task via many to one relationship

        // foreach($task as $key => $value) {
        //     if ($value->status == 1)
        //     array_push($cTask, $value);
        //     else 
        //     array_push($pTask, $value);
        // }
        // return view('todo', ['pTask' => $pTask, 'cTask' => $cTask]);
        return view('todo', ['task' => $task]);
    }
     
    // public function getTask(Request $request)
    // {
    //      $task= Task::all()->where('user_id',$request->user()->id);
    // }
    public function task(Request $request)
    { 
        
        $request->validate([
            'task'=>'required|min:3|max:500'
        ]);
    
        $task = Task::create([
            'addtask' => $request->task, // change addtask to task
            'status' => $request->status || 0,
            'user_id' => $request->user()->id
        ]);
        return $task ? json_encode(['status'=>1, 'taskObject'=> $task, 'message'=>'task created successfully']) :
        json_encode(['status'=>0, 'message'=>'Internal server error']);
        // return back();
    }

    public function updateTasksById(Request $request, $id) {
        $task = Task::find($id);
         
        if(! $task ){
            return json_encode(
                [
                    'status' => 0, 
                    'message' =>'No tasks with the given id',
                ]
            );
        }
        
        $request->validate([
            'status'=>'required|integer|min:0|max:1'
        ]);
        
        if( $task->update([
            'status'=>$request->status
        ])){
            return ($request->status==1) ? json_encode(['status'=>1, 'taskObject'=> $task, 'message'=>'Marked task as done'])
            : json_encode(['status'=>1, 'taskObject'=> $task, 'message'=>'Marked task as pending']);  
        } else {
            return json_encode(['status'=>0, 'message'=>'Internal Server Error']);  
        }
    }

    public function deleteTaskById(Request $request, $id) {

        if(! Task::find($id)){
            return json_encode(
                [
                    'status' => 0, 
                    'message' =>'No tasks with the given id',
                ]
            );
        }
    
        return (Task::find($id)->delete()) ? 
             json_encode(['status'=>1, 'message'=>'Task deleted successfully']) :
                json_encode(['status'=>0, 'message'=>'Internal Server Error']);  
    }
}

   

