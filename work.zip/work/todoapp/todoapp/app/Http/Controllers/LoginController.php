<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\User;
use Illuminate\Support\Facades\Hash;

class LoginController extends Controller
{
   public function login(Request $request)
   {
      
       $credential = $request->validate([
           'email'=>['required','email'],
           'password'=>['required'],
           ]);   
        
      if(Auth::attempt($credential,true)){

          // validation not successful, send back to form
      // $request->session()->regenerate();
       // if( ! Auth::guest()) return Redirect::to("home");

       return redirect()->intended('todo');
        }
       return back()->withErrors(['email'=>'The provided credential does not match our record',
                                 'password'=>'The provided credential does not match our record']);  

 }

   
    public function logout(Request $request){
        Auth::logout();
    $request->session()->invalidate();   
    $request->session()->regenerateToken();
        return redirect('login');
    }
 
}
